package com.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class NetconfClientManagerTest {

    @Test
    public void testGetConfig() throws Exception {
        String serverUrl = "http://172.20.0.108"; // Replace with your server URL
        NetconfClientManager clientManager = new NetconfClientManager();
        clientManager.connect(serverUrl);

        String response = clientManager.getConfig();
        assertNotNull(response);

        clientManager.close();
    }
}
